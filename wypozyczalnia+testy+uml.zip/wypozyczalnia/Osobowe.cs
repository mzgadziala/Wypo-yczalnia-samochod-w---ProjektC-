﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public class Osobowe
    {
        public int liczbaOsobowych;
        public List<SamochodOsobowy> wszystkieOsobowe;
        public List<SamochodOsobowy> dostepneOsobowe;
        

        public Osobowe()
        {
            liczbaOsobowych = 0;
            wszystkieOsobowe = new List<SamochodOsobowy>();
            
        }

        public void dodajSamochod(SamochodOsobowy s)
        {
            liczbaOsobowych++;
            wszystkieOsobowe.Add(s);
        }

        public bool jestWInwentarzu(SamochodOsobowy c)
        {
            foreach (SamochodOsobowy s in wszystkieOsobowe)
            {
                if (s.Equals(c)) return true;
            }
            return false;
        }

        public void UsunSamochod(SamochodOsobowy p)
        {
            if (jestWInwentarzu(p))
            {
                wszystkieOsobowe.Remove(p);
            }
        }

        public List<SamochodOsobowy> pokazDostepne(ListaWypozyczen lista, string dataOdbioru, string dataZwrotu)
        {
            DateTime odbior = DateTime.Parse(dataOdbioru);
            DateTime zwrot = DateTime.Parse(dataZwrotu);
            dostepneOsobowe = new List<SamochodOsobowy>(wszystkieOsobowe);

            foreach(SamochodOsobowy s in wszystkieOsobowe)
            {
                foreach(Wypozyczenie w in lista.listaWypozyczen)
                {
                    if(s == w.So && ((zwrot > w.DataOdbioru && odbior < w.DataOdbioru) || 
                        (odbior < w.DataZwrotu && zwrot > w.DataZwrotu) || (odbior > w.DataOdbioru && zwrot < w.DataZwrotu)))
                    {
                        dostepneOsobowe.Remove(s);
                    }
                }
            }
            return dostepneOsobowe;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (SamochodOsobowy s in wszystkieOsobowe)
            {
                sb.AppendLine(s.ToString());
            }
            return sb.ToString();
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
