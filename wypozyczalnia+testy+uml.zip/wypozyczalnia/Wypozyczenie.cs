﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace wypozyczalnia
{
    [Serializable]
    public enum Miasta
    {
        Warszawa = 0, Kraków = 1, Wrocław = 2, Łódź = 3, Poznań = 4, Gdańsk = 5, Szczecin = 6,
        Bydgoszcz = 7, Lublin = 8, Katowice = 9, Rzeszów = 10, Toruń = 11
    }

    public class Wypozyczenie: IZapisywalna
    {
        private Miasta miejsceOdbioru;
        private Miasta miejsceZwrotu;
        private DateTime dataOdbioru;
        private DateTime dataZwrotu;
        private Klient k;
        private SamochodOsobowy so;
        private SamochodDostawczy sd;
        private double cena;

        public Miasta MiejsceOdbioru { get => miejsceOdbioru; set => miejsceOdbioru = value; }
        public Miasta MiejsceZwrotu { get => miejsceZwrotu; set => miejsceZwrotu = value; }
        public DateTime DataOdbioru { get => dataOdbioru; set => dataOdbioru = value; }
        public DateTime DataZwrotu { get => dataZwrotu; set => dataZwrotu = value; }
        public Klient K { get => k; set => k = value; }
        public SamochodOsobowy So { get => so; set => so = value; }
        public SamochodDostawczy Sd { get => sd; set => sd = value; }
        public double Cena { get => cena; set => cena = value; }

        public static double gps;
        public static double lancuchy;
        public static double fotelik;
        public static double wyjazdZaGranice;

        static Wypozyczenie()
        {
            gps = 20.0;
            lancuchy = 25.0;
            fotelik = 20.0;
            wyjazdZaGranice = 200.0;
        }

        public Wypozyczenie(Miasta miejsceOdbioru, Miasta miejsceZwrotu, string dataOdbioru, string dataZwrotu, Klient k, SamochodOsobowy so)
        {
            DateTime data1 = DateTime.Parse(dataOdbioru);
            //DateTime.TryParseExact(dataOdbioru, new[] { "yyyy-mm-dd", "yyyy/mm/dd", "mm/dd/yyyy", "dd-mm-yy" }, null, DateTimeStyles.None, out data1);
            DateTime data2 = DateTime.Parse(dataZwrotu);
            //DateTime.TryParseExact(dataZwrotu, new[] { "yyyy-mm-dd", "yyyy/mm/dd", "mm/dd/yyyy", "dd-mm-yy" }, null, DateTimeStyles.None, out data2);

            this.miejsceOdbioru = miejsceOdbioru;
            this.miejsceZwrotu = miejsceZwrotu;
            this.dataOdbioru = data1;
            this.dataZwrotu = data2;
            this.k = k;
            this.so = so;
        }

        public Wypozyczenie(Miasta miejsceOdbioru, Miasta miejsceZwrotu, string dataOdbioru, string dataZwrotu, Klient k, SamochodDostawczy sd)
        {
            DateTime data1 = DateTime.Parse(dataOdbioru);
            //DateTime.TryParseExact(dataOdbioru, new[] { "yyyy-mm-dd", "yyyy/mm/dd", "mm/dd/yyyy", "dd-mmm-yy" }, null, DateTimeStyles.None, out data1);
            DateTime data2 = DateTime.Parse(dataZwrotu);
            //DateTime.TryParseExact(dataZwrotu, new[] { "yyyy-mm-dd", "yyyy/mm/dd", "mm/dd/yyyy", "dd-mmm-yy" }, null, DateTimeStyles.None, out data2);

            this.miejsceOdbioru = miejsceOdbioru;
            this.miejsceZwrotu = miejsceZwrotu;
            this.dataOdbioru = data1;
            this.dataZwrotu = data2;
            this.k = k;
            this.sd = sd;
        }

        public double kosztWypozyczenia() // metoda do policzenia kosztu wypożyczenia wewnątrz gui która podliczy też opłaty dodatkowe
        {
            if (so == null)
            {
                cena = sd.Cena * Convert.ToDouble((dataZwrotu - dataOdbioru).TotalDays) + SamochodDostawczy.KaucjaZwrotna + SamochodDostawczy.OplataDodatkowa;
            }
            else
            {
                cena = so.Cena * Convert.ToDouble((dataZwrotu - dataOdbioru).TotalDays) + SamochodOsobowy.KaucjaZwrotna;
            }
            return cena;
        }

        public override string ToString()
        {
            return $"Miejsce odbioru: {MiejsceOdbioru}, Miejsce zwrotu: {MiejsceZwrotu}, Kiedy: {DataOdbioru.ToShortDateString()}-{DataZwrotu.ToShortDateString()}, Klient: {k.ToString()}";
        }

        public void ZapiszXML(string nazwa, Wypozyczenie w)
        {
            var serializer = new XmlSerializer(typeof(Wypozyczenie));
            var sw = new StreamWriter(nazwa);
            serializer.Serialize(sw, w);
            sw.Close();
        }

        public object OdczytajXML(string nazwa)
        {
            Wypozyczenie wypozyczenieOdczytane;
            var fs = new FileStream(nazwa, FileMode.Open);
            var bf = new XmlSerializer(typeof(Wypozyczenie));
            wypozyczenieOdczytane = (Wypozyczenie)bf.Deserialize(fs);
            fs.Close();
            return wypozyczenieOdczytane;
        }
    }
}
