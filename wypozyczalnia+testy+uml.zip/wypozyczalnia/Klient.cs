﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wypozyczalnia;

namespace wypozyczalnia
{
    public class Klient
    {
        private string imie;
        private string nazwisko;
        private string numerTelefonu;
        private string adresEmail;
        private string numerKarty;
        private string waznoscKarty;
        private string kodZabazpieczajacy;

        public string Imie { get => imie; set => imie = value; }
        public string Nazwisko { get => nazwisko; set => nazwisko = value; }
        public string NumerTelefonu { get => numerTelefonu; set => numerTelefonu = value; }
        public string AdresEmail { get => adresEmail; set => adresEmail = value; }
        public string NumerKarty { get => numerKarty; set => numerKarty = value; }
        public string WaznoscKarty { get => waznoscKarty; set => waznoscKarty = value; }
        public string KodZabazpieczajacy { get => kodZabazpieczajacy; set => kodZabazpieczajacy = value; }

        public Klient(string imie, string nazwisko, string numerTelefonu, string adresEmail)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.numerTelefonu = numerTelefonu;
            this.adresEmail = adresEmail;
        }

        public override string ToString()
        {
            return $"{imie} {nazwisko}";
        }

    }
}
