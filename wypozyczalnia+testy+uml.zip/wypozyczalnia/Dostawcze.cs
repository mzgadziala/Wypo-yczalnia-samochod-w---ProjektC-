﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public class Dostawcze
    {
        public int liczbaDostawczych;
        public List<SamochodDostawczy> wszystkieDostawcze;
        public List<SamochodDostawczy> dostepneDostawcze;
        

        public Dostawcze()
        {
            liczbaDostawczych = 0;
            wszystkieDostawcze = new List<SamochodDostawczy>();
        }

        public void dodajSamochod(SamochodDostawczy s)
        {
            liczbaDostawczych++;
            wszystkieDostawcze.Add(s);
        }

        public bool jestWInwentarzu(SamochodDostawczy c)
        {
            foreach (SamochodDostawczy s in wszystkieDostawcze)
            {
                if (s.Equals(c)) return true;
            }
            return false;
        }

        public void UsunSamochod(SamochodDostawczy p)
        {
            if (jestWInwentarzu(p))
            {
                wszystkieDostawcze.Remove(p);
            }
        }

        public List<SamochodDostawczy> pokazDostepne(ListaWypozyczen lista, string dataOdbioru, string dataZwrotu)
        {
            DateTime odbior = DateTime.Parse(dataOdbioru);
            DateTime zwrot = DateTime.Parse(dataZwrotu);
            dostepneDostawcze = new List<SamochodDostawczy>(wszystkieDostawcze);

            foreach (SamochodDostawczy s in wszystkieDostawcze)
            {
                foreach (Wypozyczenie w in lista.listaWypozyczen)
                {
                    if (s == w.Sd && ((zwrot > w.DataOdbioru && odbior < w.DataOdbioru) ||
                        (odbior < w.DataZwrotu && zwrot > w.DataZwrotu) || (odbior > w.DataOdbioru && zwrot < w.DataZwrotu)))
                    {
                        dostepneDostawcze.Remove(s);
                    }
                }
            }
            return dostepneDostawcze;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (SamochodDostawczy s in wszystkieDostawcze)
            {
                sb.AppendLine(s.ToString());
            }
            return sb.ToString();
        }
    }
}
