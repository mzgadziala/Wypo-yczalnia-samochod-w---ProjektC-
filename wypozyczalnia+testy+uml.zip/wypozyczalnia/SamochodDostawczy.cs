﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public class SamochodDostawczy : Pojazd
    {
        private int pojemnosc;
        private static double oplataDodatkowa;
        private static double kaucjaZwrotna;

        public int Pojemnosc { get => pojemnosc; set => pojemnosc = value; }
        public static double OplataDodatkowa { get => oplataDodatkowa; set => oplataDodatkowa = value; }
        public static double KaucjaZwrotna { get => kaucjaZwrotna; set => kaucjaZwrotna = value; }

        static SamochodDostawczy()
        {
            OplataDodatkowa = 500.0;
            kaucjaZwrotna = 700.0;
        }

        public SamochodDostawczy(string marka, string model, string rocznik, Silniki silnik, Skrzynie skrzynia,
            double spalanie, double cena, int pojemnosc) : base(marka, model, rocznik, silnik, skrzynia, spalanie, cena)
        {
            this.pojemnosc = pojemnosc;
        }

        public override string ToString()
        {
            return $" {base.ToString()}, Pojemność: {pojemnosc} kilogramów";
        }

    }
}
