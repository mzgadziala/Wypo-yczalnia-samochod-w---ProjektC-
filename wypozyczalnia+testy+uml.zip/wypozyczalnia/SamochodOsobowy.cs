﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public class SamochodOsobowy : Pojazd
    {
        private static double kaucjaZwrotna;
        private int liczbaOsob;
        public int LiczbaOsob { get => liczbaOsob; set => liczbaOsob = value; }
        public static double KaucjaZwrotna { get => kaucjaZwrotna; set => kaucjaZwrotna = value; }

        static SamochodOsobowy()
        {
            KaucjaZwrotna = 400.0;
        }

        public SamochodOsobowy() : base()
        {

        }

        public SamochodOsobowy(string marka, string model, string rocznik, Silniki silnik, Skrzynie skrzynia,
            double spalanie, double cena, int liczbaOsob) : base(marka, model, rocznik, silnik, skrzynia, spalanie, cena)
        {
            this.liczbaOsob = liczbaOsob;
        }

        public override string ToString()
        {
            return $" {base.ToString()}, Liczba osób: {liczbaOsob}";
        }

    }
}
