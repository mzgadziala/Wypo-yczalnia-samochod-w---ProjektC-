﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public enum Silniki { Benzyna = 0, Diesel = 1, Diesel3 = 2, BenzynaTSI = 3 };
    public enum Skrzynie { Manualna = 0, Automatyczna = 1 };

    public abstract class Pojazd
    {
        private string marka;
        private string model;
        private string rocznik;
        private Silniki silnik;
        private Skrzynie skrzynia;
        private double spalanie;
        private double cena;

        public string Marka { get => marka; set => marka = value; }
        public string Model { get => model; set => model = value; }
        public string Rocznik { get => rocznik; set => rocznik = value; }
        public Silniki Silnik { get => silnik; set => silnik = value; }
        public Skrzynie Skrzynia { get => skrzynia; set => skrzynia = value; }
        public double Spalanie { get => spalanie; set => spalanie = value; }
        public double Cena { get => cena; set => cena = value; }


        public Pojazd()
        {
            marka = null;
            model = null;
            rocznik = null;
            silnik = Silniki.Benzyna;
            skrzynia = Skrzynie.Manualna;
            spalanie = 0.0;
            cena = 0;
        }

        public Pojazd(string marka, string model)
        {
            this.marka = marka;
            this.model = model;
        }

        public Pojazd(string marka, string model, string rocznik, Silniki silnik, Skrzynie skrzynia,
            double spalanie, double cena)
        {
            this.marka = marka;
            this.model = model;
            this.rocznik = rocznik;
            this.silnik = silnik;
            this.skrzynia = skrzynia;
            this.spalanie = spalanie;
            this.cena = cena;
        }

        public override string ToString()
        {
            return $"Samochód: {Marka} {Model}, Rok produkcji: {Rocznik}, Silnik: {Silnik}, Skrzynia: {Skrzynia}, Spalanie: {Spalanie} l/100 km, Cena: {Cena}/dzień";
        }
    }
}