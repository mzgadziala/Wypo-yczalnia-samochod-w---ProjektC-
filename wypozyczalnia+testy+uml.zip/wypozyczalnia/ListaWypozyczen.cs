﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wypozyczalnia
{
    public class ListaWypozyczen
    {
        public int liczbaWypozyczen = 0;
        public List<Wypozyczenie> listaWypozyczen = new List<Wypozyczenie>();

        //public ListaWypozyczen()
        //{
        //    liczbaWypozyczen = 0;
        //    listaWypozyczen = new List<Wypozyczenie>();
        //}

        public void dodaj(Wypozyczenie w)
        {
            listaWypozyczen.Add(w);
            liczbaWypozyczen++;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Wypozyczenie w in listaWypozyczen)
            {
                sb.AppendLine(w.ToString());
            }
            return sb.ToString();
        }

    }


    //usuń (
    //znajdź (na podstawie klienta)
}
